---
name: Reactie of wijzigingsvoorstel
about: Meld een fout, vraag of voorstel voor de ILS
labels: reactie
---

**Hoofdstuk / IDS-bestand:**

**Check(s):** #

**Wat klopt er niet of wat stel je voor?**

**Onderbouwing (wet, norm, praktijk):**

**Organisatie (optioneel):**
