# Concept-specificaties fysieke elementen (23 november 2026)

Vijf nieuwe IDS-bestanden voor de ILS Omgevingsvergunning, opgezet zoals de bestaande 9.18-specificaties (34 tot en met 42). Ze horen nog niet bij versie 0.2.0; in de bestanden staat versie `0.3.0-concept`.

| Bestand | Specificatie | IFC-klasse | Checks |
|---|---|---|---|
| 45-9.18j-Fysieke-elementen-IfcRoof.ids | 9.18j Dak | IfcRoof | 2, 6, 9, 11, 13, 16 |
| 46-9.18k-Fysieke-elementen-IfcStair.ids | 9.18k Trap | IfcStair | 10, 16 |
| 47-9.18l-Fysieke-elementen-IfcRamp.ids | 9.18l Hellingbaan | IfcRamp | 10 |
| 48-9.18m-Fysieke-elementen-IfcTransportElement.ELEVATOR.ids | 9.18m Lift | IfcTransportElement, type ELEVATOR | 9, 10 |
| 49-9.18n-Fysieke-elementen-IfcRailing.ids | 9.18n Leuning en afscheiding | IfcRailing | 10 |

## Uitgangspunten
- Alle eisen zijn optioneel en `minOccurs` is 0: een model wordt niet afgekeurd omdat het element of de eigenschap ontbreekt; alleen een ingevulde waarde die niet klopt wordt afgekeurd.
- Alleen standaard IFC-eigenschappen. Naam, property set en datatype zijn nagelopen in de property set-definities van IFC4 en IFC4X3_ADD2 (IfcOpenShell 0.9.0).
- `FireRating` heeft hetzelfde voorlopige patroon als in de bestaande 9.18-specificaties.
- De `identifier` is het specificatienummer, omdat er voor deze elementen nog geen klasse in de bSDD "Omgevingswet Ruimten" is nagegaan.
- Een bordes (IfcSlab, type LANDING) en een dakvlak als IfcSlab (type ROOF) vallen onder de bestaande 9.18g.

## Getest
- Geldig tegen het IDS 1.0-schema (IfcTester).
- Getest met IfcTester op vier kleine testmodellen (IFC4 en IFC4X3_ADD2, elk met goede en foute waarden): `REI 60` slaagt, `60` wordt afgekeurd; de liftspecificatie is alleen van toepassing op type ELEVATOR en niet op een roltrap.
- Niet getest op een model uit Revit of Archicad.

## Regels voor data/specificaties_checks.csv (voorstel)
```
45,45-9.18j-Fysieke-elementen-IfcRoof.ids,9.18j Fysieke elementen IfcRoof,IFC4 IFC4X3_ADD2,9.18j,#2 #6 #9 #11 #13 #16,O,O,V,
46,46-9.18k-Fysieke-elementen-IfcStair.ids,9.18k Fysieke elementen IfcStair,IFC4 IFC4X3_ADD2,9.18k,#10 #16,O,O,V,
47,47-9.18l-Fysieke-elementen-IfcRamp.ids,9.18l Fysieke elementen IfcRamp,IFC4 IFC4X3_ADD2,9.18l,#10,O,O,V,
48,48-9.18m-Fysieke-elementen-IfcTransportElement.ELEVATOR.ids,9.18m Fysieke elementen IfcTransportElement.ELEVATOR,IFC4 IFC4X3_ADD2,9.18m,#9 #10,O,O,V,
49,49-9.18n-Fysieke-elementen-IfcRailing.ids,9.18n Fysieke elementen IfcRailing,IFC4 IFC4X3_ADD2,9.18n,#10,O,O,V,
```
Let op: check 2 en 6 horen bij mijlpaal M2 (aanvraag OPA). Volgens de regel uit hoofdstuk 05 zou 9.18j dan bij M2 verplicht worden; hierboven staat O, omdat een dak als IfcSlab ook voldoet. Dat is een keuze om te maken.

## Prompt voor VS Code
```
Neem de vijf concept-IDS-bestanden 45 tot en met 49 op in ids/. Voeg de vijf regels toe
aan data/specificaties_checks.csv, genereer hoofdstuk 05 en 06 opnieuw (NL en EN), werk
de telling bij (46 specificaties) en zet een regel per specificatie in de changelog onder
een nieuwe kop [Niet uitgebracht]. Zet de afgeleide bestanden (BM13 deel A, bijlage C) op
de achterstandslijst. Valideer alle IDS-bestanden. Commit en push niets.
```
