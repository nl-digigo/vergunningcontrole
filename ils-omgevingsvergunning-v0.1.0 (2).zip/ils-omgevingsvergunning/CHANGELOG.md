# Changelog

Dit project volgt [semantische versies](https://semver.org/lang/nl/). `0.x` = concept, `1.0.0` = vastgesteld.

## [0.1.0] – 2026-09-17

### Toegevoegd
- Eerste ReSpec-publicatie van de ILS Omgevingsvergunning, opgebouwd volgens het digiGO Toetsingskader ILS en het ILS-Referentiesjabloon.
- Tabel met vereisten: 17 checks gekoppeld aan 42 IDS-deelspecificaties.
- Level of Information Need, per specificatie gegenereerd uit de IDS, plus geometrische eisen G1–G6.
- Acceptatiecriteria AC1–AC7.
- Hoofdstuk geometrische controle (tweeledige aanpak, SPARQL-regels en generieke functies).
- Verantwoording per criterium van het Toetsingskader ILS.

### Gewijzigd
- Informatiedoelstellingen hernummerd: ID01 = omgevingsplanactiviteit bouwen (checks #1–#6), ID02 = technische bouwactiviteit (checks #7–#17). De overige doelstellingen zijn ID03–ID12 geworden (voorheen ID01–ID08; ID11 en ID12 ongewijzigd).
- ID01-informatie wordt bij ID02 (aanvraag technische bouwactiviteit, M3) opnieuw en bijgewerkt meegeleverd.
- ID03–ID12 zijn optioneel: voorstellen om op te nemen, nog niet onderzocht.
- Matrix toegevoegd die de informatiedoelstellingen koppelt aan de GEMMA-processen (013, 015-02 t/m 015-05, toezicht en handhaving, brondatabeheer, evaluatie).
- GEMMA-verwijzing gecorrigeerd: de toetsing valt onder 015-03 *Inhoudelijk behandelen aanvraag* (niet 015-02). Aangepast in de tekst en in `ids:milestone` van alle 42 IDS-bestanden.
