---
name: Beslispunt
about: Een keuze die in het projectoverleg of bij digiGO moet worden gemaakt
labels: beslispunt
---

**Vraag:**

**Opties:**
1.
2.

**Advies redactie:**

**Besluit door (projectoverleg / stuurgroep / digiGO):**
